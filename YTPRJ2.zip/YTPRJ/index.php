<?php include 'includes/nav.php';
require 'includes/search.php';
require 'includes/Update.php';
?>

<div class="container bg-light radius-10 shadow-sm p-3">

  <div class="row m-3 justify-content-center">
    <?php

    $query = mysqli_query($db, "SELECT * FROM `person`");
    while ($row = mysqli_fetch_assoc($query)) {
      include 'includes/card.php';
    } ?>


  </div>
</div>