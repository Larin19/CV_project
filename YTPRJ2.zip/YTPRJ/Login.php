<?php include 'includes/nav.php'; ?>

<?php

if (isset($_POST['adminlogin'])) {
    $user = x($_POST['username']);
    $pass = x($_POST['password']);

    if (empty($user) || empty($pass)) {
        header("Location: login.php");
    } else {
        $query = mysqli_query($db, "SELECT * FROM `admin` WHERE `username` = '$user' AND `password` = '$pass' ");
        if (mysqli_num_rows($query) == 1) {
            while ($row = mysqli_fetch_assoc($query)) {
                $_SESSION['admin'] = x($user);
            }
            header("Location: index.php");
        } else {
            header("Location: login.php");
        }
    }
}

?>


<div class="container text-center mt-4 bg-light p-4">

    <img src="assets/img/user.png" alt="" class="userbtn m-4" width="150">
    <img src="assets/img/admin (1).png" alt="" class="adminbtn m-4" width="150">

    <div class="row justify-content-center">
        <?php
        $i = 0;
        while ($i <= 1) { ?>
            <form action="Login.php" method="POST" class="<?php if ($i == 0) {
                                                                echo 'user';
                                                            } else {
                                                                echo 'company';
                                                            } ?> d-none m-2 col-lg-5 col-sm bg-white p-4 radius-10">
                <input name="username" type="text" placeholder="Username" class="form-control form-control-lg mt-3">
                <input name="password" type="text" placeholder="Password" class="form-control form-control-lg mt-3">
                <button <?php if ($i == 0) {
                            echo 'name=userlogin';
                        } else {
                            echo 'name="adminlogin"';
                        } ?>class="btn <?php if ($i == 0) {
                                            echo 'btn-warning';
                                        } else {
                                            echo 'btn-primary';
                                        } ?> mt-2 w-100">Login</button>
            </form>
        <?php
            $i++;
        } ?>
    </div>
</div>