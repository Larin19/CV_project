  <!-- Modal -->
  <div class="modal fade" id="post<?php echo x($row['id']); ?>" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
      <div class="modal-dialog">
          <div class="modal-content">
              <div class="modal-body text-center">
                  <form action="index.php" method="POST">
                      <input type="text" name="id" value="<?php echo x($row['id']) ?>" hidden>
                      <input name="name" type="text" class="from form-control mt-2" value="<?php echo x($row['name']) ?>">
                      <input name="age" type="text" class="from form-control mt-2" value="<?php echo x($row['age']) ?>">
                      <input name="job" type="text" class="from form-control mt-2" value="<?php echo x($row['job']) ?>">

                      <button name="update" class="btn btn-warning mt-2 w-25">Update</button>
                      <button type="button" class="btn btn-primary mt-2 w-25" data-bs-dismiss="modal">Close</button>
                  </form>
              </div>
          </div>
      </div>
  </div>
  <div class="card m-2 border-0 p-3 radius-10 shadow-sm" style="width: 18rem;">
      <img src="assets/img/<?php echo x($row['photo']); ?>" class="w-50 m-auto">
      <div class="card-body text-center">
          <h5 class="card-title">Name : <?php echo x($row['name']); ?></h5>
          <p class="card-text">Age : <?php echo x($row['age']); ?></p>
          <p class="card-text">Job : <?php echo x($row['job']); ?></p>
          <a href="#">View CV</a>
      </div>
      <?php
        if (isset($_SESSION['admin'])) { ?>
          <a href="?d=<?php echo x($row['id']); ?>"><img src="assets/img/remove.svg" width="40" style="position:absolute;top:0;right:0;margin:10px" alt=""></a>
          <span data-bs-toggle="modal" data-bs-target="#post<?php echo x($row['id']); ?>"><img src="assets/img/pencil.png" width="40"></span>
      <?php } ?>


  </div>