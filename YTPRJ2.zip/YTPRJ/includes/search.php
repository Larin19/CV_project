<?php
if (isset($_GET['search'])) {
    $data = x($_GET['search']);
    $query = mysqli_query($db, "SELECT * FROM `person` WHERE `name` LIKE '%$data%'");
    if (mysqli_num_rows($query) > 0) { ?>
        <div class="container bg-light radius-10 shadow-sm p-3">
            <div class="row m-3 justify-content-center">
                <?php while ($row = mysqli_fetch_assoc($query)) {
                    include 'includes/card.php';
                } ?>
            </div>
        </div>


<?php  } else {
        echo "<p class='p-4 text-center text-danger container n-auto'> there is no data </p>";
    }
    exit();
}



?>